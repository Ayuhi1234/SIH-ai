# Demo Video
https://github.com/Surbh77/AI-teacher/assets/108724393/35b67b0a-bc67-48b0-b4fc-f012fdca376a

# Installation
Just clone this git repository and go live with index.html the website will start

# 3D Avatars
This repo has avatar.glb and avatar1.glb files. Each file containes different avatars. You can change the avatars in the index.js file

# Lip-Syncing
This project uses the google tts api key. Paste the respective api key in the index.js file for proper and accurate lipsync of the avatar
